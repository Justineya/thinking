# CPT FastAPI Backend

## Run

```bash
cp .env.example .env
docker compose up
```

API docs: `http://localhost:8000/docs`

## Core endpoints

- `POST /api/portfolio`
- `GET /api/portfolio?window_days=30`
- `GET /api/portfolio/{id}`
- `PATCH /api/portfolio/{id}`
- `DELETE /api/portfolio/{id}`
- `PUT /api/cycle` to insert/update a calculated market snapshot
- `GET /api/cycle/{ticker}?window_days=30`
- `GET /api/cycle?zone=build&window_days=30`
- `GET /api/cycle?min_score=0&max_score=3&search=CO`

## Example cycle upsert

```json
{
  "ticker": "COHR",
  "window_days": 30,
  "current_price": 301.88,
  "period_low": 255.25,
  "period_high": 386.23
}
```

The backend calculates and stores the 0-10 score and zone. Market-data ingestion is intentionally decoupled: a separate provider adapter or scheduler should call `PUT /api/cycle` after obtaining valid bars.
