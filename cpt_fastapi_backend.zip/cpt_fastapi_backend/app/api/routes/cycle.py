from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import and_, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.models.cycle import CycleScore
from app.schemas.cycle import CycleRead, CycleUpsert, ZoneKey
from app.services.cycle_engine import calculate_score, distance_to_high_pct, zone_from_score

router = APIRouter(prefix="/cycle", tags=["cycle"])

def to_read(row: CycleScore) -> CycleRead:
    return CycleRead(ticker=row.ticker, window_days=row.window_days,
        current_price=row.current_price, period_low=row.period_low,
        period_high=row.period_high, score=row.score, zone=row.zone,
        distance_to_high_pct=distance_to_high_pct(row.current_price, row.period_high),
        updated_at=row.updated_at)

@router.put("", response_model=CycleRead)
async def upsert_cycle(payload: CycleUpsert, db: AsyncSession = Depends(get_db)):
    score = calculate_score(payload.current_price, payload.period_low, payload.period_high)
    zone = zone_from_score(score)
    values = payload.model_dump() | {"score": score, "zone": zone}
    stmt = insert(CycleScore).values(**values).on_conflict_do_update(
        index_elements=[CycleScore.ticker, CycleScore.window_days],
        set_={k: values[k] for k in ["current_price", "period_low", "period_high", "score", "zone"]}
    ).returning(CycleScore)
    row = (await db.execute(stmt)).scalar_one()
    await db.commit()
    return to_read(row)

@router.get("/{ticker}", response_model=CycleRead)
async def get_cycle(ticker: str, window_days: int = 30, db: AsyncSession = Depends(get_db)):
    row = await db.get(CycleScore, (ticker.upper(), window_days))
    if not row:
        raise HTTPException(404, "Cycle score not found")
    return to_read(row)

@router.get("", response_model=list[CycleRead])
async def filter_cycles(
    zone: ZoneKey | None = None,
    min_score: Decimal | None = Query(default=None, ge=0, le=10),
    max_score: Decimal | None = Query(default=None, ge=0, le=10),
    window_days: int = Query(default=30, ge=5, le=120),
    search: str | None = None,
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    filters = [CycleScore.window_days == window_days]
    if zone: filters.append(CycleScore.zone == zone)
    if min_score is not None: filters.append(CycleScore.score >= min_score)
    if max_score is not None: filters.append(CycleScore.score <= max_score)
    if search: filters.append(CycleScore.ticker.ilike(f"%{search.strip()}%"))
    stmt = select(CycleScore).where(and_(*filters)).order_by(CycleScore.score, CycleScore.ticker).limit(limit).offset(offset)
    rows = (await db.execute(stmt)).scalars().all()
    return [to_read(row) for row in rows]
