from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.models.cycle import CycleScore
from app.models.portfolio import PortfolioHolding
from app.schemas.portfolio import HoldingCreate, HoldingRead, HoldingUpdate, HoldingWithMetrics

router = APIRouter(prefix="/portfolio", tags=["portfolio"])

@router.post("", response_model=HoldingRead, status_code=status.HTTP_201_CREATED)
async def create_holding(payload: HoldingCreate, db: AsyncSession = Depends(get_db)):
    item = PortfolioHolding(**payload.model_dump())
    db.add(item)
    await db.commit()
    await db.refresh(item)
    return item

@router.get("", response_model=list[HoldingWithMetrics])
async def list_holdings(window_days: int = 30, db: AsyncSession = Depends(get_db)):
    stmt = (select(PortfolioHolding, CycleScore)
            .outerjoin(CycleScore, (CycleScore.ticker == PortfolioHolding.underlying) & (CycleScore.window_days == window_days))
            .order_by(PortfolioHolding.created_at.desc()))
    rows = (await db.execute(stmt)).all()
    result = []
    for holding, cycle in rows:
        data = HoldingRead.model_validate(holding).model_dump()
        if cycle:
            mv = holding.shares * cycle.current_price
            cost = holding.shares * holding.cost_price
            data.update(underlying_current_price=cycle.current_price, market_value=mv,
                        unrealized_pnl=mv-cost, cycle_score=cycle.score, zone=cycle.zone)
        result.append(HoldingWithMetrics(**data))
    return result

@router.get("/{holding_id}", response_model=HoldingWithMetrics)
async def get_holding(holding_id: int, window_days: int = 30, db: AsyncSession = Depends(get_db)):
    stmt = (select(PortfolioHolding, CycleScore)
            .outerjoin(CycleScore, (CycleScore.ticker == PortfolioHolding.underlying) & (CycleScore.window_days == window_days))
            .where(PortfolioHolding.id == holding_id))
    row = (await db.execute(stmt)).first()
    if not row:
        raise HTTPException(404, "Holding not found")
    holding, cycle = row
    data = HoldingRead.model_validate(holding).model_dump()
    if cycle:
        mv = holding.shares * cycle.current_price
        data.update(underlying_current_price=cycle.current_price, market_value=mv,
                    unrealized_pnl=mv-holding.shares*holding.cost_price,
                    cycle_score=cycle.score, zone=cycle.zone)
    return HoldingWithMetrics(**data)

@router.patch("/{holding_id}", response_model=HoldingRead)
async def update_holding(holding_id: int, payload: HoldingUpdate, db: AsyncSession = Depends(get_db)):
    item = await db.get(PortfolioHolding, holding_id)
    if not item:
        raise HTTPException(404, "Holding not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(item, key, value)
    await db.commit(); await db.refresh(item)
    return item

@router.delete("/{holding_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_holding(holding_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(delete(PortfolioHolding).where(PortfolioHolding.id == holding_id))
    if result.rowcount == 0:
        raise HTTPException(404, "Holding not found")
    await db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
